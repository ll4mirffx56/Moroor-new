# مرور | Moroor — سیستم مدیریت مطالعه

مرور یک اپلیکیشن فارسی و راست‌چین برای برنامه‌ریزی مطالعه، مرور فاصله‌دار، ثبت آزمون، دوره‌های آموزشی، گزارش‌های واقعی و یادداشت است. سایت عمومی و داشبورد هر دو با **Next.js App Router** اجرا می‌شوند؛ داده‌ها و منطق مطالعه از نسخهٔ قبل حفظ شده‌اند.

## استک

- Next.js 15 (App Router) + React 19 + TypeScript
- Tailwind CSS + shadcn/ui (Button، Badge، Dialog، Command)
- Framer Motion برای reveal و تعامل کامپوننت‌ها
- GSAP + ScrollTrigger برای stacking و پارالاکس
- Lenis برای اسکرول نرم (فقط pointer دقیق و بدون کاهش حرکت)
- React Three Fiber + Three.js فقط در hero، به‌صورت lazy و با fallback سبک روی موبایل

## مسیرها

- `/` — لندینگ معرفی با preloader، hero شیدر، bento، stacking cards، command palette و ۴۰۴ سفارشی.
- `/app/` — داشبورد کاربردی با مسیریابی hash برای بخش‌ها: داشبورد، برنامه و مرور، عملکرد آزمونی، دوره‌ها، گزارش‌ها، یادداشت و تنظیمات.

داشبورد در حالت بدون Supabase به‌صورت «حالت محلی» کار می‌کند و این وضعیت را اعلام می‌کند. با تنظیم متغیرهای محیطی، ورود و همگام‌سازی حساب‌محور فعال می‌شود.

## اجرا

نیازمند Node.js 20+:

```bash
npm install
npm run dev
# http://localhost:3000
```

ساخت خروجی استاتیک:

```bash
npm run build     # خروجی در out/
npm run preview   # سرو کردن out/
npm test          # ۲۶ آزمون منطق داده و هم‌زمانی
npm run typecheck
```

## متغیرهای محیطی

`.env.example` را به `.env.local` کپی کن:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

هرگز `service_role` یا Secret key را در فرانت‌اند یا متغیر `NEXT_PUBLIC_` قرار نده. راهنمای کامل: `CLOUD-SETUP.md`.

## داده و همگام‌سازی

معماری داده عوض نشده است: یک سند JSON نسخه‌دار (`schemaVersion: 2`) در `public.user_app_state` با RLS، Realtime و compare-and-swap. مهاجرت دادهٔ نسخهٔ ۱ و کلیدهای قدیمی `localStorage` در خود برنامه و بدون حذف انجام می‌شود. سه migration موجود در `supabase/migrations/` بدون تغییر باقی مانده‌اند.

## انتشار

Workflow در `.github/workflows/deploy.yml` با `npm ci` تست و Build می‌کند و فقط از شاخهٔ `main` منتشر می‌شود. برای GitHub Pages، `NEXT_PUBLIC_BASE_PATH` به‌صورت خودکار برابر نام مخزن تنظیم می‌شود و خروجی `out/` آپلود می‌شود. مسیرهای داخلی Next به‌صورت خودکار basePath را رعایت می‌کنند.

## محدودیت‌ها

ورود/ثبت‌نام واقعی Supabase، RLS، Realtime و همگام‌سازی دو دستگاه بدون پروژه و اعتبارنامهٔ Supabase در این محیط آزمون نشده‌اند. جزئیات آزمون‌های انجام‌شده در `TEST-REPORT.md` آمده است.
