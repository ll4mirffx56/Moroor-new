'use client'

import {
  AnimatePresence,
  motion,
  useInView,
  useReducedMotion,
} from 'framer-motion'
import {
  Fragment,
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react'
import { faNumber } from '@/lib/date'
import { cn } from '@/lib/utils'
import { useMounted, usePointerFine } from '@/lib/theme'

/* ------------------------------- Preloader -------------------------------- */

export function Preloader() {
  const reduced = useReducedMotion()
  const mounted = useMounted()
  const [visible, setVisible] = useState(true)
  const countRef = useRef<HTMLDivElement>(null)
  const barRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (reduced) {
      setVisible(false)
      return
    }
    try {
      if (sessionStorage.getItem('moroor-preloaded') === '1') {
        setVisible(false)
        return
      }
    } catch {
      /* ignore */
    }
    let frame = 0
    const start = performance.now()
    const tick = (now: number) => {
      const percent = Math.min(100, Math.round(((now - start) / 900) * 100))
      if (countRef.current) countRef.current.textContent = faNumber(percent, 0)
      if (barRef.current) barRef.current.style.transform = `scaleX(${percent / 100})`
      if (percent < 100) {
        frame = requestAnimationFrame(tick)
      } else {
        window.setTimeout(() => {
          try {
            sessionStorage.setItem('moroor-preloaded', '1')
          } catch {
            /* ignore */
          }
          setVisible(false)
        }, 300)
      }
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [reduced])

  if (mounted && reduced) return null

  return (
    <AnimatePresence>
      {visible ? (
        <motion.div
          className="landing-preloader"
          initial={false}
          exit={{ y: '-100%' }}
          transition={{ duration: 0.65, ease: [0.76, 0, 0.24, 1] }}
          aria-hidden="true"
        >
          <div className="landing-preloader-inner">
            <div className="landing-preloader-count" ref={countRef}>{faNumber(0, 0)}</div>
            <div className="landing-preloader-label">MOROOR / STUDY SYSTEM</div>
            <div className="landing-preloader-bar">
              <i ref={barRef} style={{ transform: 'scaleX(0)', transformOrigin: 'left' }} />
            </div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}

/* ------------------------------- Split text ------------------------------- */

/**
 * Persian words are shaped as one word cluster; splitting into individual
 * letters breaks Arabic/Persian joining. We split by words instead, preserving
 * the typography while still creating the staggered reveal.
 */
export function SplitWords({
  text,
  className,
  delay = 0,
  once = true,
}: {
  text: string
  className?: string
  delay?: number
  once?: boolean
}) {
  const reduced = useReducedMotion()
  const mounted = useMounted()
  const words = text.split(' ')

  // The word wrapper stays in the layout and is what the observer watches; the
  // letter cluster is clipped below it, so putting whileInView on the clipped
  // node would give IntersectionObserver a zero-area target and never start.
  const wordVariants = {
    hidden: {},
    show: { transition: { staggerChildren: 0.055, delayChildren: delay } },
  }
  const charVariants = {
    // Keep the text painted for LCP; the masked word rise is the reveal.
    hidden: { y: '24%', opacity: 1 },
    show: { y: 0, opacity: 1, transition: { duration: 0.75, ease: [0.22, 1, 0.36, 1] as const } },
  }

  if (mounted && reduced) {
    return <span className={cn('inline', className)}>{text}</span>
  }

  return (
    <span className={cn('inline', className)}>
      {words.map((word, index) => (
        <Fragment key={`${word}-${index}`}>
          <motion.span
            className="landing-split-word"
            initial={reduced ? false : 'hidden'}
            whileInView={reduced ? undefined : 'show'}
            viewport={{ once, margin: '-8%' }}
            variants={reduced ? undefined : wordVariants}
          >
            <motion.span className="landing-split-char" variants={reduced ? undefined : charVariants}>
              {word}
            </motion.span>
          </motion.span>
          {index < words.length - 1 ? ' ' : null}
        </Fragment>
      ))}
    </span>
  )
}

/* --------------------------------- Reveal --------------------------------- */

export function Reveal({
  children,
  delay = 0,
  className,
  amount = 0.2,
}: {
  children: ReactNode
  delay?: number
  className?: string
  amount?: number
}) {
  const reduced = useReducedMotion()
  const mounted = useMounted()
  if (mounted && reduced) return <div className={className}>{children}</div>
  return (
    <motion.div
      className={className}
      initial={reduced ? false : { opacity: 1, y: 18 }}
      whileInView={reduced ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, amount }}
      transition={{ delay, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

/* ------------------------------- Magnetic --------------------------------- */

export function Magnetic({
  children,
  className,
  strength = 8,
}: {
  children: ReactNode
  className?: string
  strength?: number
}) {
  const ref = useRef<HTMLDivElement>(null)
  const fine = usePointerFine()
  const reduced = useReducedMotion()

  const move = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (!fine || reduced || !ref.current) return
      const rect = ref.current.getBoundingClientRect()
      const x = ((event.clientX - rect.left) / rect.width - 0.5) * strength * 2
      const y = ((event.clientY - rect.top) / rect.height - 0.5) * strength * 2
      ref.current.style.transform = `translate3d(${x}px, ${y}px, 0)`
    },
    [fine, reduced, strength],
  )

  const reset = useCallback(() => {
    if (ref.current) ref.current.style.transform = 'translate3d(0, 0, 0)'
  }, [])

  return (
    <div
      ref={ref}
      className={cn('will-change-transform', className)}
      style={{ transition: 'transform 0.28s cubic-bezier(0.22, 1, 0.36, 1)' }}
      onPointerMove={move}
      onPointerLeave={reset}
    >
      {children}
    </div>
  )
}

/* ------------------------------ Spotlight --------------------------------- */

export function SpotlightCard({
  children,
  className,
  style,
  ...rest
}: {
  children: ReactNode
  className?: string
  style?: CSSProperties
  'data-wide'?: string
  'data-tall'?: string
  'data-small'?: string
}) {
  const ref = useRef<HTMLDivElement>(null)
  const fine = usePointerFine()

  const move = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (!fine || !ref.current) return
      const rect = ref.current.getBoundingClientRect()
      ref.current.style.setProperty('--mx', `${event.clientX - rect.left}px`)
      ref.current.style.setProperty('--my', `${event.clientY - rect.top}px`)
    },
    [fine],
  )

  return (
    <div ref={ref} className={cn('landing-bento-card', className)} style={style} onPointerMove={move} {...rest}>
      {children}
    </div>
  )
}

/* -------------------------------- Cursor ---------------------------------- */

export function LandingCursor() {
  const fine = usePointerFine()
  const reduced = useReducedMotion()
  const dot = useRef<HTMLDivElement>(null)
  const target = useRef({ x: 0, y: 0 })
  const current = useRef({ x: 0, y: 0 })
  const [active, setActive] = useState(false)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (!fine || reduced) return
    const onMove = (event: PointerEvent) => {
      target.current = { x: event.clientX, y: event.clientY }
      setVisible(true)
      const element = (event.target as Element | null)?.closest?.('a,button,[role="button"],input,textarea,select,[data-cursor]')
      setActive(Boolean(element))
    }
    const onLeave = () => setVisible(false)
    let frame = 0
    const loop = () => {
      current.current.x += (target.current.x - current.current.x) * 0.18
      current.current.y += (target.current.y - current.current.y) * 0.18
      if (dot.current) {
        dot.current.style.transform = `translate3d(${current.current.x}px, ${current.current.y}px, 0)`
      }
      frame = requestAnimationFrame(loop)
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    document.documentElement.addEventListener('pointerleave', onLeave)
    frame = requestAnimationFrame(loop)
    return () => {
      window.removeEventListener('pointermove', onMove)
      document.documentElement.removeEventListener('pointerleave', onLeave)
      cancelAnimationFrame(frame)
    }
  }, [fine, reduced])

  if (!fine || reduced) return null

  return (
    <div
      ref={dot}
      className="landing-cursor"
      data-active={active}
      data-visible={visible}
      aria-hidden="true"
      style={{ opacity: visible ? 1 : 0 }}
    />
  )
}

/* ------------------------------- Clock chip ------------------------------- */

export function ClockChip({ className }: { className?: string }) {
  const [time, setTime] = useState('—')

  useEffect(() => {
    const formatter = new Intl.DateTimeFormat('fa-IR', {
      timeZone: 'Asia/Tehran',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    })
    const update = () => setTime(formatter.format(new Date()))
    update()
    const timer = window.setInterval(update, 1000)
    return () => window.clearInterval(timer)
  }, [])

  return (
    <span className={cn('landing-clock', className)} title="ساعت زندهٔ تهران">
      <i className="landing-clock-dot" aria-hidden="true" />
      <span>تهران</span>
      <b dir="ltr" style={{ fontWeight: 600 }}>{time}</b>
    </span>
  )
}

/* -------------------------------- CountUp --------------------------------- */

export function CountUp({
  value,
  suffix = '',
  prefix = '',
  duration = 1300,
  className,
}: {
  value: number
  suffix?: string
  prefix?: string
  duration?: number
  className?: string
}) {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-10%' })
  const reduced = useReducedMotion()
  const [display, setDisplay] = useState(0)

  useEffect(() => {
    if (!inView) return
    if (reduced) {
      setDisplay(value)
      return
    }
    let frame = 0
    const start = performance.now()
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplay(Math.round(value * eased))
      if (progress < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [inView, reduced, value, duration])

  return (
    <span ref={ref} className={className}>
      {prefix}{faNumber(display, 0)}{suffix}
    </span>
  )
}

/* ------------------------------ Scramble ---------------------------------- */

export function ScrambleText({
  text,
  className,
  as = 'span',
}: {
  text: string
  className?: string
  as?: 'span' | 'p'
}) {
  const ref = useRef<HTMLElement>(null)
  const inView = useInView(ref, { once: true, margin: '-5%' })
  const reduced = useReducedMotion()
  const [display, setDisplay] = useState(text)

  useEffect(() => {
    if (!inView || reduced) {
      setDisplay(text)
      return
    }
    const glyphs = '01<>[]{}/\\—+*'
    let frame = 0
    let step = 0
    const total = 12
    const timer = window.setInterval(() => {
      step += 1
      if (step >= total) {
        setDisplay(text)
        window.clearInterval(timer)
        return
      }
      setDisplay(
        text
          .split('')
          .map((char, index) => {
            if (char === ' ') return ' '
            if (index < (step / total) * text.length) return char
            return glyphs[(frame + index) % glyphs.length]
          })
          .join(''),
      )
      frame += 1
    }, 46)
    return () => {
      window.clearInterval(timer)
    }
  }, [inView, reduced, text])

  const Tag = as
  return (
    <Tag ref={ref as never} className={cn('landing-scramble', className)}>
      <span aria-hidden="true">{display}</span>
      <span className="sr-only">{text}</span>
    </Tag>
  )
}

/* -------------------------------- Skeleton -------------------------------- */

export function Skeleton({ className }: { className?: string }) {
  return <span className={cn('landing-skeleton', className)} aria-hidden="true" />
}
