'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

export type ThemeName = 'dark' | 'light'

const THEME_KEY = 'moroor-theme'
const STATE_KEY = 'moroor-state-v2'

export function readTheme(): ThemeName {
  if (typeof document === 'undefined') return 'dark'
  return document.documentElement.dataset.theme === 'light' ? 'light' : 'dark'
}

/** Applies the theme globally and keeps the dashboard document in sync. */
export function applyTheme(theme: ThemeName): void {
  if (typeof document === 'undefined') return
  document.documentElement.dataset.theme = theme
  try {
    localStorage.setItem(THEME_KEY, theme)
    const raw = localStorage.getItem(STATE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as { settings?: Record<string, unknown> }
      if (parsed && typeof parsed === 'object' && parsed.settings) {
        parsed.settings = { ...parsed.settings, theme }
        localStorage.setItem(STATE_KEY, JSON.stringify(parsed))
      }
    }
  } catch {
    /* private mode or full storage: the current session still updates */
  }
}

export function applyReduceMotion(value: boolean): void {
  if (typeof document === 'undefined') return
  document.documentElement.dataset.reduceMotion = value ? 'true' : 'false'
}

export function useLandingTheme() {
  const [theme, setTheme] = useState<ThemeName>('dark')

  useEffect(() => {
    setTheme(readTheme())
  }, [])

  const toggle = useCallback(() => {
    setTheme(current => {
      const next: ThemeName = current === 'dark' ? 'light' : 'dark'
      applyTheme(next)
      return next
    })
  }, [])

  const set = useCallback((next: ThemeName) => {
    applyTheme(next)
    setTheme(next)
  }, [])

  return { theme, toggle, setTheme: set }
}

export function usePointerFine() {
  const [fine, setFine] = useState(false)
  useEffect(() => {
    const query = window.matchMedia('(pointer: fine)')
    const update = () => setFine(query.matches)
    update()
    query.addEventListener('change', update)
    return () => query.removeEventListener('change', update)
  }, [])
  return fine
}

export function useDocumentVisible() {
  const [visible, setVisible] = useState(true)
  useEffect(() => {
    const update = () => setVisible(document.visibilityState === 'visible')
    update()
    document.addEventListener('visibilitychange', update)
    return () => document.removeEventListener('visibilitychange', update)
  }, [])
  return visible
}

export function usePersistentFlag(key: string) {
  const ref = useRef(false)
  useEffect(() => {
    try {
      ref.current = localStorage.getItem(key) === '1'
    } catch {
      ref.current = false
    }
  }, [key])
  return ref
}

/** Avoids server/client markup differences for preference-dependent UI. */
export function useMounted() {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  return mounted
}
