'use client'

import dynamic from 'next/dynamic'
import { Component, useEffect, useState, type ReactNode } from 'react'
import { useReducedMotion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import { Skeleton } from './motion'

const HeroScene = dynamic(() => import('./HeroScene'), {
  ssr: false,
  loading: () => <SceneFallback />,
})

class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false }

  static getDerivedStateFromError() {
    return { failed: true }
  }

  render() {
    if (this.state.failed) return this.props.fallback
    return this.props.children
  }
}

function SceneFallback() {
  return (
    <div className="landing-hero-fallback" aria-hidden="true">
      <div className="landing-scene-skeleton">
        <Skeleton className="landing-scene-orb" />
        <Skeleton className="landing-scene-line" />
        <Skeleton className="landing-scene-line short" />
      </div>
    </div>
  )
}

function StaticHero() {
  return (
    <div className="landing-static-hero" aria-hidden="true">
      <span className="landing-static-glow" />
      <span className="landing-static-ring ring-a" />
      <span className="landing-static-ring ring-b" />
      <span className="landing-static-mark">م</span>
      <span className="landing-static-label">MOROOR / STUDY OS</span>
    </div>
  )
}

export function HeroVisual({ theme }: { theme: 'dark' | 'light' }) {
  const reduced = useReducedMotion()
  const [allowed, setAllowed] = useState(false)

  useEffect(() => {
    const query = window.matchMedia('(max-width: 760px)')
    const update = () => {
      const canvas = document.createElement('canvas')
      const supported = Boolean(canvas.getContext('webgl2') || canvas.getContext('webgl'))
      setAllowed(!query.matches && !reduced && supported)
    }
    update()
    query.addEventListener('change', update)
    return () => query.removeEventListener('change', update)
  }, [reduced])

  return (
    <div className="landing-hero-visual" data-cursor="view">
      <span className="landing-hero-badge landing-hero-badge-a">
        <Sparkles size={15} aria-hidden="true" />
        <span>
          <strong>مرور فاصله‌دار</strong>
          <span>۱ / ۲ / ۴ / ۷ روز</span>
        </span>
      </span>
      <span className="landing-hero-badge landing-hero-badge-b">
        <span>
          <strong>تحلیل واقعی</strong>
          <span>بدون دادهٔ ساختگی</span>
        </span>
      </span>
      {allowed ? (
        <SceneBoundary fallback={<SceneFallback />}>
          <HeroScene theme={theme} />
        </SceneBoundary>
      ) : (
        <StaticHero />
      )}
      <span className="landing-hero-hint">
        <span>WebGL / Liquid field</span>
        <span>{allowed ? 'برای اعوجاج، نشانگر را حرکت بده' : 'نسخهٔ سبک'}</span>
      </span>
    </div>
  )
}
