import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: ['selector', '[data-theme="dark"]'],
  corePlugins: { preflight: false },
  content: [
    './src/app/**/*.{ts,tsx}',
    './src/components/**/*.{ts,tsx}',
    './src/views/**/*.{ts,tsx}',
    './src/App.tsx',
  ],
  theme: {
    extend: {
      colors: {
        ink: 'var(--text)',
        muted: 'var(--muted)',
        line: 'var(--line)',
        accent: 'var(--accent)',
        violet: 'var(--violet)',
        surface: 'var(--surface-solid)',
      },
      fontFamily: {
        sans: ['var(--font)', 'Tahoma', 'sans-serif'],
      },
      borderRadius: {
        xl: 'calc(var(--radius) + 4px)',
      },
      screens: {
        xs: '420px',
      },
    },
  },
  plugins: [],
}

export default config
