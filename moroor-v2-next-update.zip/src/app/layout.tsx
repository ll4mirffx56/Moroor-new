import type { Metadata, Viewport } from 'next'
import '../styles.css'
import '../styles/fonts.css'
import '../styles/landing.css'
import './globals.css'

export const metadata: Metadata = {
  title: {
    default: 'مرور | Moroor — سیستم مدیریت مطالعه',
    template: '%s | مرور',
  },
  description:
    'مرور، دستیار مطالعهٔ فارسی: برنامه‌ریزی، مرور فاصله‌دار، آزمون، دوره، گزارش و همگام‌سازی حساب‌محور.',
  applicationName: 'Moroor',
  authors: [{ name: 'Moroor' }],
  openGraph: {
    title: 'مرور | Moroor',
    description: 'سیستم مدیریت مطالعه و تحلیل یادگیری با تقویم شمسی.',
    type: 'website',
    locale: 'fa_IR',
  },
  robots: { index: true, follow: true },
}

export const viewport: Viewport = {
  themeColor: '#080a12',
  colorScheme: 'dark light',
  width: 'device-width',
  initialScale: 1,
}

const themeScript = `
try {
  var stored = localStorage.getItem('moroor-theme');
  document.documentElement.dataset.theme = stored === 'light' ? 'light' : 'dark';
  if (sessionStorage.getItem('moroor-preloaded') === '1') {
    document.documentElement.dataset.preloaded = 'true';
  }
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.dataset.reduced = 'true';
  }
} catch (error) {
  document.documentElement.dataset.theme = 'dark';
}
`

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <a className="skip-link" href="#main-content">
          پرش به محتوای اصلی
        </a>
        {children}
      </body>
    </html>
  )
}
