'use client'

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'

const vertexShader = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

const fragmentShader = /* glsl */ `
  precision highp float;
  uniform float uTime;
  uniform vec2 uMouse;
  uniform float uHover;
  uniform vec2 uResolution;
  uniform sampler2D uTexture;
  varying vec2 vUv;

  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }

  float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for (int i = 0; i < 4; i++) {
      value += amplitude * noise(p);
      p *= 2.02;
      amplitude *= 0.5;
    }
    return value;
  }

  void main() {
    vec2 uv = vUv;
    vec2 mouse = uMouse;
    float dist = distance(uv, mouse);
    float hover = smoothstep(0.34, 0.0, dist) * (0.35 + uHover * 0.65);

    vec2 flow = vec2(
      sin(uv.y * 5.2 + uTime * 0.45),
      cos(uv.x * 5.6 - uTime * 0.38)
    ) * (0.018 + uHover * 0.028);

    vec2 warped = uv + flow;
    float liquid = fbm(warped * 3.1 + vec2(uTime * 0.045, -uTime * 0.03));
    warped += vec2(
      sin(liquid * 6.283 + uTime * 0.25),
      cos(liquid * 5.4 - uTime * 0.21)
    ) * 0.026 * (0.35 + uHover);

    vec3 deep = vec3(0.035, 0.05, 0.11);
    vec3 blue = vec3(0.29, 0.42, 0.94);
    vec3 violet = vec3(0.58, 0.45, 0.95);
    float bands = smoothstep(0.2, 0.95, liquid);
    vec3 color = mix(deep, blue, bands * 0.55);
    color = mix(color, violet, smoothstep(0.55, 1.0, liquid) * 0.5);
    color += hover * vec3(0.18, 0.28, 0.62);

    vec3 textureColor = texture2D(uTexture, warped).rgb;
    color = mix(color, textureColor, 0.42 + uHover * 0.12);

    float vignette = smoothstep(1.15, 0.32, length((uv - 0.5) * vec2(1.07, 1.0)));
    color *= 0.58 + vignette * 0.62;
    float grain = (hash(gl_FragCoord.xy * 0.75) - 0.5) * 0.032;
    color += grain;

    gl_FragColor = vec4(color, 1.0);
  }
`

function createTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 1024
  canvas.height = 1024
  const context = canvas.getContext('2d')
  if (context) {
    const gradient = context.createLinearGradient(0, 0, 1024, 1024)
    gradient.addColorStop(0, '#10152a')
    gradient.addColorStop(0.45, '#20326b')
    gradient.addColorStop(0.72, '#493a88')
    gradient.addColorStop(1, '#0a0d18')
    context.fillStyle = gradient
    context.fillRect(0, 0, 1024, 1024)

    context.globalAlpha = 0.22
    context.strokeStyle = '#9fb4ff'
    context.lineWidth = 1
    for (let x = 0; x <= 1024; x += 64) {
      context.beginPath()
      context.moveTo(x, 0)
      context.lineTo(x, 1024)
      context.stroke()
    }
    for (let y = 0; y <= 1024; y += 64) {
      context.beginPath()
      context.moveTo(0, y)
      context.lineTo(1024, y)
      context.stroke()
    }
    context.globalAlpha = 1

    context.strokeStyle = 'rgba(190, 205, 255, 0.28)'
    context.lineWidth = 2
    for (let index = 0; index < 4; index += 1) {
      context.beginPath()
      context.arc(512, 512, 140 + index * 92, 0, Math.PI * 2)
      context.stroke()
    }

    context.fillStyle = 'rgba(238, 242, 255, 0.92)'
    context.font = '900 152px Arial, sans-serif'
    context.textAlign = 'center'
    context.textBaseline = 'middle'
    context.fillText('M', 512, 500)

    context.fillStyle = 'rgba(168, 188, 255, 0.82)'
    context.font = '600 22px Arial, sans-serif'
    context.letterSpacing = '12px'
    context.fillText('MOROOR / 1405', 512, 620)
  }
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  return texture
}

function LiquidPlane({ theme }: { theme: 'dark' | 'light' }) {
  const material = useRef<THREE.ShaderMaterial>(null)
  const hover = useRef(0)
  const pointer = useRef(new THREE.Vector2(0.5, 0.5))
  const { viewport } = useThree()

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0.5, 0.5) },
      uHover: { value: 0 },
      uResolution: { value: new THREE.Vector2(1, 1) },
      uTexture: { value: createTexture() },
    }),
    [],
  )

  useEffect(() => {
    const materialValue = material.current
    return () => {
      if (materialValue) materialValue.uniforms.uTexture.value?.dispose?.()
    }
  }, [])

  useEffect(() => {
    if (material.current) {
      material.current.uniforms.uTime.value = theme === 'light' ? 1 : 0
    }
  }, [theme])

  useFrame((state) => {
    if (!material.current) return
    const current = material.current.uniforms
    current.uTime.value = state.clock.elapsedTime
    current.uHover.value += (hover.current - current.uHover.value) * 0.06
    current.uMouse.value.lerp(pointer.current, 0.045)
    current.uResolution.value.set(state.size.width, state.size.height)
  })

  return (
    <mesh
      scale={[viewport.width, viewport.height, 1]}
      onPointerMove={(event) => {
        pointer.current.set(event.uv?.x ?? 0.5, event.uv?.y ?? 0.5)
      }}
      onPointerOver={() => { hover.current = 1 }}
      onPointerOut={() => { hover.current = 0 }}
    >
      <planeGeometry args={[1, 1, 1, 1]} />
      <shaderMaterial
        ref={material}
        uniforms={uniforms}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
      />
    </mesh>
  )
}

export default function HeroScene({ theme }: { theme: 'dark' | 'light' }) {
  return (
    <Canvas
      className="landing-hero-canvas"
      orthographic
      camera={{ position: [0, 0, 1], zoom: 1 }}
      dpr={[1, 1.6]}
      gl={{ antialias: false, alpha: true, powerPreference: 'high-performance' }}
      style={{ position: 'absolute', inset: 0 }}
    >
      <LiquidPlane theme={theme} />
    </Canvas>
  )
}
