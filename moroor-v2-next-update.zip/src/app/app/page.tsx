'use client'

import dynamic from 'next/dynamic'

const DashboardApp = dynamic(() => import('@/App'), {
  ssr: false,
  loading: () => (
    <div className="splash" role="status" aria-live="polite">
      <div className="brand brand-auth">
        <div className="brand-mark" aria-hidden="true">م</div>
        <div><strong>مرور</strong><span>Moroor V2</span></div>
      </div>
      <p className="muted" style={{ marginTop: 18 }}>در حال آماده‌سازی داشبورد…</p>
    </div>
  ),
})

export default function DashboardRoute() {
  return <DashboardApp />
}
