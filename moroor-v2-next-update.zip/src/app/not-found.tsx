import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'صفحه پیدا نشد',
  description: 'این مسیر در مرور وجود ندارد.',
}

export default function NotFound() {
  return (
    <main className="landing-shell not-found-shell">
      <div className="landing-grain" aria-hidden="true" />
      <div className="landing-container not-found-inner">
        <p className="landing-kicker">404 / صفحه پیدا نشد</p>
        <h1 className="not-found-code" aria-hidden="true">۴۰۴</h1>
        <h2 className="landing-h2">این صفحه از دفتر برنامه خارج شده است.</h2>
        <p className="landing-sub">
          آدرس را بررسی کن یا از مسیرهای زیر ادامه بده.
        </p>
        <div className="landing-cta-row">
          <Link className="btn btn-primary" href="/">بازگشت به خانه</Link>
          <Link className="btn btn-secondary" href="/app">ورود به داشبورد</Link>
        </div>
      </div>
    </main>
  )
}
