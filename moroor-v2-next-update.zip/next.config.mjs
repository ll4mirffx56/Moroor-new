/** @type {import('next').NextConfig} */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || ''

const nextConfig = {
  output: 'export',
  trailingSlash: true,
  basePath,
  images: { unoptimized: true },
  reactStrictMode: true,
  webpack: (config) => {
    // Node's native test runner needs explicit .js specifiers; Next resolves
    // those specifiers back to the TypeScript sources.
    config.resolve.extensionAlias = {
      '.js': ['.ts', '.tsx', '.js'],
      '.mjs': ['.mts', '.mjs'],
      '.cjs': ['.cts', '.cjs'],
    }
    return config
  },
  allowedDevOrigins: ['pv-c6b40c2bc35f-12ee9b50-bdff-46cf-a26c-e69e369914cc.style.dev'],
}

export default nextConfig
