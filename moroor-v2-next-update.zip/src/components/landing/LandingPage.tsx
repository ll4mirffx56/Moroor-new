'use client'

import Link from 'next/link'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
import {
  ArrowDown,
  ArrowLeft,
  BookOpenCheck,
  CalendarCheck2,
  ChartLine,
  Check,
  Command as CommandIcon,
  Database,
  Gauge,
  Layers3,
  LockKeyhole,
  Menu,
  Moon,
  PlayCircle,
  ShieldCheck,
  Sparkles,
  Sun,
  TimerReset,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { scrollToSection } from '@/lib/scroll'
import { useLandingTheme } from '@/lib/theme'
import { useSoundDesign, type SoundDesign } from './sound'
import { HeroVisual } from './HeroVisual'
import { SmoothScroll } from './SmoothScroll'
import dynamic from 'next/dynamic'

const CommandMenu = dynamic(
  () => import('./CommandMenu').then((module) => module.CommandMenu),
  { ssr: false },
)

const Toaster = dynamic(
  () => import('sonner').then((module) => module.Toaster),
  { ssr: false },
)
import {
  ClockChip,
  CountUp,
  LandingCursor,
  Magnetic,
  Preloader,
  Reveal,
  ScrambleText,
  SplitWords,
  SpotlightCard,
} from './motion'

const NAV_LINKS = [
  { id: 'features', label: 'امکانات' },
  { id: 'how', label: 'چطور کار می‌کند' },
  { id: 'data', label: 'داده و امنیت' },
  { id: 'start', label: 'شروع' },
]

const SUBJECTS = [
  'فیزیک', 'شیمی', 'حسابان', 'هندسه', 'گسسته', 'آمار و احتمال',
  'فارسی', 'عربی', 'دینی', 'زبان انگلیسی',
]

const STACK_STEPS = [
  {
    title: 'هر روز را ثبت کن',
    body: 'ساعت مطالعه، تست، پاسخ صحیح و غلط را در چند ثانیه وارد کن. پاسخ نزده خودکار محاسبه می‌شود و فرمول درصد آزمون همیشه یکسان می‌ماند: ((صحیح × ۳) − غلط) ÷ (کل × ۳).',
  },
  {
    title: 'مرور را به سیستم بسپار',
    body: 'برای هر موضوع، موعد بعدی بر اساس تسلط پیشنهاد می‌شود. مرورهای امروز، عقب‌افتاده و زمان‌بندی‌شده یک‌جا دیده می‌شوند و در صورت نیاز تاریخ را دستی تغییر می‌دهی.',
  },
  {
    title: 'از داده، تصمیم بگیر',
    body: 'گزارش هفتگی و ماهانه فقط از رکوردهای واقعی ساخته می‌شود. اگر داده کافی نباشد، برنامه به‌جای نتیجه‌گیری الکی می‌گوید «داده کافی نیست».',
  },
]

function Nav({
  theme,
  onToggleTheme,
  soundEnabled,
  onToggleSound,
  onOpenCommand,
  play,
}: {
  theme: 'dark' | 'light'
  onToggleTheme: () => void
  soundEnabled: boolean
  onToggleSound: () => void
  onOpenCommand: () => void
  play: SoundDesign['play']
}) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  function go(id: string) {
    setMobileOpen(false)
    play('tap')
    scrollToSection(id)
  }

  return (
    <header className="landing-nav" data-scrolled={scrolled}>
      <div className="landing-nav-inner">
        <Link href="/" className="landing-brand" aria-label="مرور، خانه" onClick={() => play('tap')}>
          <span className="landing-brand-mark" aria-hidden="true">م</span>
          <span>
            مرور
            <small>MOROOR / STUDY OS</small>
          </span>
        </Link>

        <nav className="landing-nav-links" aria-label="ناوبری اصلی">
          {NAV_LINKS.map(link => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={event => {
                event.preventDefault()
                go(link.id)
              }}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="landing-nav-actions">
          <button
            type="button"
            className="landing-icon-btn landing-command-trigger"
            onClick={() => { play('tap'); onOpenCommand() }}
            aria-label="باز کردن دستورها"
            title="دستورها — Ctrl K"
          >
            <CommandIcon size={16} aria-hidden="true" />
            <kbd>⌘K</kbd>
          </button>
          <button
            type="button"
            className="landing-icon-btn"
            onClick={() => { play('tap'); onToggleSound() }}
            aria-pressed={soundEnabled}
            aria-label={soundEnabled ? 'قطع صدا' : 'روشن‌کردن صدا'}
            title={soundEnabled ? 'قطع صدا' : 'صدا (پیش‌فرض خاموش)'}
          >
            {soundEnabled ? <Volume2 size={16} aria-hidden="true" /> : <VolumeX size={16} aria-hidden="true" />}
          </button>
          <button
            type="button"
            className="landing-icon-btn"
            onClick={() => { play('tap'); onToggleTheme() }}
            aria-label={theme === 'dark' ? 'روشن‌کردن تم' : 'تیره‌کردن تم'}
            title={theme === 'dark' ? 'تم روشن' : 'تم تیره'}
          >
            {theme === 'dark' ? <Sun size={16} aria-hidden="true" /> : <Moon size={16} aria-hidden="true" />}
          </button>
          <Button asChild size="sm" className="landing-nav-cta">
            <Link href="/app" onClick={() => play('confirm')}>
              ورود به داشبورد
              <ArrowLeft size={14} aria-hidden="true" />
            </Link>
          </Button>
          <button
            type="button"
            className="landing-icon-btn landing-menu-trigger"
            onClick={() => setMobileOpen(value => !value)}
            aria-expanded={mobileOpen}
            aria-controls="landing-mobile-nav"
            aria-label={mobileOpen ? 'بستن منو' : 'باز کردن منو'}
          >
            {mobileOpen ? <X size={16} aria-hidden="true" /> : <Menu size={16} aria-hidden="true" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen ? (
          <motion.nav
            id="landing-mobile-nav"
            className="landing-mobile-nav"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            aria-label="ناوبری موبایل"
          >
            {NAV_LINKS.map(link => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={event => {
                  event.preventDefault()
                  go(link.id)
                }}
              >
                {link.label}
              </a>
            ))}
            <Link href="/app" onClick={() => { setMobileOpen(false); play('confirm') }}>
              ورود به داشبورد
              <ArrowLeft size={14} aria-hidden="true" />
            </Link>
          </motion.nav>
        ) : null}
      </AnimatePresence>
    </header>
  )
}

function Hero({ theme, play }: { theme: 'dark' | 'light'; play: SoundDesign['play'] }) {
  return (
    <section className="landing-hero" id="top" aria-labelledby="hero-title">
      <div className="landing-container">
        <div className="landing-hero-grid">
          <div>
            <Reveal>
              <div className="landing-eyebrow">
                <i aria-hidden="true" />
                سیستم مطالعهٔ نسخهٔ ۲
                <span className="landing-eyebrow-divider" aria-hidden="true">/</span>
                <ClockChip />
              </div>
            </Reveal>

            <h1 className="landing-title" id="hero-title">
              <span className="line"><SplitWords text="مطالعه‌ات را" delay={0.1} /></span>{' '}
              <span className="line gradient"><SplitWords text="به سیستم" delay={0.18} /></span>{' '}
              <span className="line gradient"><SplitWords text="تبدیل کن." delay={0.26} /></span>
            </h1>

            <Reveal delay={0.35}>
              <p className="landing-lede">
                مرور، از ساعت‌های مطالعه و تست‌های امروز تا مرورهای آینده و گزارش‌های هفتگی،
                یک تصویر واقعی از پیشرفتت می‌سازد. فارسی، راست‌چین و بدون دادهٔ ساختگی.
              </p>
            </Reveal>

            <Reveal delay={0.45}>
              <div className="landing-cta-row">
                <Magnetic>
                  <Button asChild size="lg" onClick={() => play('confirm')}>
                    <Link href="/app">
                      شروع با داشبورد
                      <ArrowLeft size={16} aria-hidden="true" />
                    </Link>
                  </Button>
                </Magnetic>
                <Button
                  variant="secondary"
                  size="lg"
                  onClick={() => {
                    play('tap')
                    scrollToSection('features')
                  }}
                >
                  دیدن امکانات
                  <ArrowDown size={15} aria-hidden="true" />
                </Button>
              </div>
            </Reveal>

            <Reveal delay={0.55}>
              <div className="landing-meta-row">
                <span><Check size={14} aria-hidden="true" /> ۶ بخش یکپارچه</span>
                <span><CalendarCheck2 size={14} aria-hidden="true" /> تقویم شمسی</span>
                <span><ShieldCheck size={14} aria-hidden="true" /> همگام‌سازی حساب‌محور</span>
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.2} amount={0.1}>
            <HeroVisual theme={theme} />
          </Reveal>
        </div>
      </div>
    </section>
  )
}

function Marquee() {
  const items = [...SUBJECTS, ...SUBJECTS]
  return (
    <div className="landing-marquee" aria-label="درس‌های پیش‌فرض">
      <div className="landing-marquee-track">
        {items.map((subject, index) => (
          <span className="landing-marquee-item" key={`${subject}-${index}`} aria-hidden={index >= SUBJECTS.length}>
            <Sparkles size={12} aria-hidden="true" />
            {subject}
          </span>
        ))}
      </div>
    </div>
  )
}

function Features() {
  return (
    <section className="landing-section" id="features" aria-labelledby="features-title">
      <div className="landing-container">
        <div className="landing-section-head">
          <div>
            <ScrambleText text="FEATURES / SYSTEM" className="landing-kicker" />
            <h2 className="landing-h2" id="features-title">
              <SplitWords text="هر چیزی که برای یک مطالعهٔ منظم لازم داری." />
            </h2>
          </div>
          <p className="landing-sub">
            شش بخش که به هم وصل‌اند: برنامه، مرور، آزمون، دوره، گزارش و تنظیمات.
            هیچ عددی از جای دیگری نمی‌آید؛ همه‌چیز از ثبت‌های خودت ساخته می‌شود.
          </p>
        </div>

        <div className="landing-bento">
          <SpotlightCard data-wide="true" className="landing-gradient-border">
            <span className="landing-bento-icon"><TimerReset size={19} aria-hidden="true" /></span>
            <h3>مرور فاصله‌دار، بدون فراموشی</h3>
            <p>
              فاصله‌های ۱، ۲، ۴ و ۷ روز برای سطح‌های ضعیف، متوسط، خوب و عالی؛
              با امکان تغییر و تعیین دستی موعد.
            </p>
            <div className="visual landing-mini-chart" aria-hidden="true">
              {[28, 44, 34, 66, 52, 82, 64, 92, 72, 100].map((height, index) => (
                <i key={index} style={{ height: `${height}%` }} />
              ))}
            </div>
          </SpotlightCard>

          <SpotlightCard data-wide="true">
            <span className="landing-bento-icon"><ChartLine size={19} aria-hidden="true" /></span>
            <h3>درصد آزمون، شفاف</h3>
            <p>
              نمرهٔ منفی سه‌به‌یک، پاسخ نزده بدون جریمه و درصد کل از مجموع پاسخ‌ها؛
              نه میانگین گمراه‌کنندهٔ درس‌ها.
            </p>
            <div className="landing-formula" aria-hidden="true">
              <span>((۲۰ × ۳) − ۵)</span>
              <b>÷</b>
              <span>(۳۰ × ۳)</span>
            </div>
          </SpotlightCard>

          <SpotlightCard data-small="true">
            <span className="landing-bento-icon"><CalendarCheck2 size={19} aria-hidden="true" /></span>
            <h3>تقویم شمسی واقعی</h3>
            <p>انتخاب تاریخ با تقویم پاپ‌آپ؛ ذخیره‌سازی ISO و نمایش شمسی، بدون پرش روز.</p>
            <div className="landing-mini-calendar" aria-hidden="true">
              {Array.from({ length: 21 }).map((_, index) => (
                <i key={index} data-active={index === 14} data-muted={index < 4 || index > 17} />
              ))}
            </div>
          </SpotlightCard>

          <SpotlightCard>
            <span className="landing-bento-icon"><PlayCircle size={19} aria-hidden="true" /></span>
            <h3>دوره‌ها با دو معیار</h3>
            <p>پیشرفت ویدئو جدا از پیشرفت وزنی مراحل یادگیری؛ تمرین، آزمون و تسلط هرکدام وزن خودشان را دارند.</p>
            <div className="landing-progress-stack" aria-hidden="true">
              <span><i style={{ transform: 'scaleX(0.66)' }} /></span>
              <span><i style={{ transform: 'scaleX(0.42)' }} /></span>
            </div>
          </SpotlightCard>

          <SpotlightCard>
            <span className="landing-bento-icon"><Layers3 size={19} aria-hidden="true" /></span>
            <h3>بدهی مطالعاتی</h3>
            <p>کارهای عقب‌افتاده، امروز و آینده با اولویت، سختی و وابستگی؛ مرتب‌سازی خودکار یا دستی.</p>
            <div className="landing-debt" aria-hidden="true">
              <Badge variant="positive">عقب‌افتاده</Badge>
              <Badge variant="accent">امروز</Badge>
              <Badge>پیش‌رو</Badge>
            </div>
          </SpotlightCard>

          <SpotlightCard data-wide="true">
            <span className="landing-bento-icon"><Gauge size={19} aria-hidden="true" /></span>
            <h3>گزارش‌هایی که به تصمیم می‌رسند</h3>
            <p>
              مقایسهٔ هفته‌به‌هفته، نقاط قوت و مسئله، بیشترین پیشرفت و افت،
              کارهای ناتمام و پیشنهادهای مبتنی بر همان داده.
            </p>
            <div className="landing-heatmap" aria-hidden="true">
              {Array.from({ length: 35 }).map((_, index) => (
                <i key={index} data-level={(index * 7) % 5} />
              ))}
            </div>
          </SpotlightCard>

          <SpotlightCard data-wide="true">
            <span className="landing-bento-icon"><BookOpenCheck size={19} aria-hidden="true" /></span>
            <h3>یادداشت متصل</h3>
            <p>یادداشت به درس، فصل، موضوع، دوره یا آزمون وصل می‌شود و با جست‌وجو پیدا می‌شود.</p>
            <div className="landing-note" aria-hidden="true">
              <span />
              <span />
              <span className="short" />
            </div>
          </SpotlightCard>
        </div>
      </div>
    </section>
  )
}

function StackSection() {
  const root = useRef<HTMLDivElement>(null)
  const reduced = useReducedMotion()
  const [nearViewport, setNearViewport] = useState(false)

  useEffect(() => {
    const node = root.current
    if (!node) return
    if (!('IntersectionObserver' in window)) {
      setNearViewport(true)
      return
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return
        setNearViewport(true)
        observer.disconnect()
      },
      { rootMargin: '320px 0px' },
    )
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (reduced || !nearViewport) return
    let context: { revert: () => void } | null = null
    let cancelled = false
    void (async () => {
      const [{ default: gsap }, { ScrollTrigger }] = await Promise.all([
        import('gsap'),
        import('gsap/ScrollTrigger'),
      ])
      if (cancelled || !root.current) return
      gsap.registerPlugin(ScrollTrigger)
      context = gsap.context(() => {
        const cards = gsap.utils.toArray<HTMLElement>('.landing-stack-card')
        cards.forEach((card, index) => {
          if (index === cards.length - 1) return
          gsap.to(card, {
            scale: 0.945,
            opacity: 0.55,
            ease: 'none',
            scrollTrigger: {
              trigger: cards[index + 1],
              start: 'top 82%',
              end: 'top 38%',
              scrub: true,
            },
          })
        })
      }, root)
      ScrollTrigger.refresh()
    })()
    return () => {
      cancelled = true
      context?.revert()
    }
  }, [reduced, nearViewport])

  return (
    <section className="landing-section" id="how" aria-labelledby="how-title">
      <div className="landing-container">
        <div className="landing-section-head">
          <div>
            <ScrambleText text="FLOW / 01—03" className="landing-kicker" />
            <h2 className="landing-h2" id="how-title">
              <SplitWords text="سه قدم، یک حلقهٔ یادگیری." />
            </h2>
          </div>
          <p className="landing-sub">
            ثبت، مرور و تحلیل. هر بخش ورودی بخش بعدی را می‌سازد و هیچ داده‌ای جای دیگری
            بازنویسی نمی‌شود.
          </p>
        </div>

        <div className="landing-stack" ref={root}>
          {STACK_STEPS.map((step, index) => (
            <article
              className="landing-stack-card"
              key={step.title}
              style={{ '--i': index } as CSSProperties}
            >
              <span className="landing-stack-index" aria-hidden="true">۰{index + 1}</span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.body}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function DataSection() {
  return (
    <section className="landing-section" id="data" aria-labelledby="data-title">
      <div className="landing-container">
        <div className="landing-data-grid">
          <div>
            <ScrambleText text="DATA / OWNERSHIP" className="landing-kicker" />
            <h2 className="landing-h2" id="data-title">
              <SplitWords text="داده‌ات مال خودت است؛ سیستم فقط آن را حفظ می‌کند." />
            </h2>
            <p className="landing-sub" style={{ marginTop: 16 }}>
              هر حساب فقط ردیف خودش را می‌خواند. نوشتن با نسخه و مقایسه انجام می‌شود،
              تغییر هم‌زمان بی‌صدا حذف نمی‌شود و ورود فایل پشتیبان چیزی را پاک نمی‌کند.
            </p>
            <ul className="landing-check-list">
              <li><ShieldCheck size={16} aria-hidden="true" /> دسترسی ردیفی با RLS و مالکیت همان کاربر</li>
              <li><LockKeyhole size={16} aria-hidden="true" /> بدون کلید سرویس در مرورگر</li>
              <li><Database size={16} aria-hidden="true" /> پشتیبان JSON و Excel با پیش‌نمایش</li>
              <li><Check size={16} aria-hidden="true" /> مهاجرت خودکار داده‌های نسخهٔ قبل</li>
            </ul>
            <Button asChild variant="secondary" className="mt-7">
              <Link href="/app#/notes/account">
                تنظیمات حساب و همگام‌سازی
                <ArrowLeft size={15} aria-hidden="true" />
              </Link>
            </Button>
          </div>

          <div className="landing-data-panel" aria-label="معماری داده">
            <div className="landing-data-panel-head">
              <span className="landing-brand-mark" aria-hidden="true">م</span>
              <div>
                <strong>Moroor / data path</strong>
                <span dir="ltr">schema v2 · owner-scoped</span>
              </div>
            </div>
            <div className="landing-data-flow">
              <span><LockKeyhole size={15} /> Supabase Auth</span>
              <i />
              <span><ShieldCheck size={15} /> Row Level Security</span>
              <i />
              <span><Database size={15} /> JSON v2</span>
              <i />
              <span><Check size={15} /> Compare &amp; swap</span>
            </div>
            <div className="landing-data-foot">
              <Badge variant="positive">مسیر محلی همیشه در دسترس</Badge>
              <span>بدون ثبت دادهٔ نمایشی</span>
            </div>
          </div>
        </div>

        <div className="landing-metrics">
          <div className="landing-metric"><strong><CountUp value={6} /></strong><span>بخش یکپارچه</span></div>
          <div className="landing-metric"><strong><CountUp value={10} /></strong><span>درس پیش‌فرض، قابل افزودن</span></div>
          <div className="landing-metric"><strong><CountUp value={4} /></strong><span>سطح تسلط برای مرور</span></div>
          <div className="landing-metric"><strong><CountUp value={100} suffix="٪" /></strong><span>مالکیت دادهٔ حساب</span></div>
        </div>
      </div>
    </section>
  )
}

function StartSection({ play }: { play: SoundDesign['play'] }) {
  return (
    <section className="landing-section" id="start" aria-labelledby="start-title">
      <div className="landing-container">
        <div className="landing-cta landing-gradient-border">
          <Badge variant="accent" className="mx-auto">
            <Sparkles size={12} aria-hidden="true" />
            نسخهٔ ۲ · آمادهٔ استفاده
          </Badge>
          <h2 id="start-title" style={{ marginTop: 22 }}>
            <SplitWords text="امروز اولین روزِ سیستماتیک باشد." />
          </h2>
          <p>
            بدون ثبت‌نام اجباری شروع کن؛ داده‌ها روی همین دستگاه می‌مانند.
            وقتی آماده بودی، حساب بساز تا بین دستگاه‌ها همگام شوند.
          </p>
          <div className="landing-cta-row" style={{ justifyContent: 'center' }}>
            <Magnetic>
              <Button asChild size="lg" onClick={() => play('confirm')}>
                <Link href="/app">
                  ورود به داشبورد
                  <ArrowLeft size={16} aria-hidden="true" />
                </Link>
              </Button>
            </Magnetic>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => {
                play('tap')
                scrollToSection('features')
              }}
            >
              مرور امکانات
            </Button>
          </div>
          <div className="landing-cta-foot">
            <span><Check size={14} aria-hidden="true" /> بدون کارت بانکی</span>
            <span><Check size={14} aria-hidden="true" /> بدون دادهٔ ساختگی</span>
            <span><Check size={14} aria-hidden="true" /> بدون قفل کردن خروجی</span>
          </div>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="landing-footer">
      <div className="landing-container landing-footer-inner">
        <Link href="/" className="landing-brand" aria-label="مرور">
          <span className="landing-brand-mark" aria-hidden="true">م</span>
          <span>مرور<small>MOROOR / STUDY OS</small></span>
        </Link>
        <p>ساخته‌شده برای مطالعهٔ منظم، با تقویم شمسی و دادهٔ واقعی. © ۱۴۰۵</p>
        <div className="landing-footer-links">
          <Link href="/app">داشبورد</Link>
          <a href="https://github.com/ll4mirffx56/Konkur-System" target="_blank" rel="noopener noreferrer">GitHub</a>
        </div>
      </div>
    </footer>
  )
}

export function LandingPage() {
  const { theme, toggle: toggleTheme } = useLandingTheme()
  const { soundEnabled, toggleSound, play } = useSoundDesign()
  const [commandOpen, setCommandOpen] = useState(false)
  const [toasterReady, setToasterReady] = useState(false)
  const reduced = useReducedMotion()

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setToasterReady(true)
        setCommandOpen((current) => !current)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  useEffect(() => {
    if (reduced || window.matchMedia('(max-width: 760px)').matches) return
    let context: { revert: () => void } | null = null
    let cancelled = false
    void (async () => {
      const [{ default: gsap }, { ScrollTrigger }] = await Promise.all([
        import('gsap'),
        import('gsap/ScrollTrigger'),
      ])
      if (cancelled) return
      gsap.registerPlugin(ScrollTrigger)
      context = gsap.context(() => {
        const visual = document.querySelector('.landing-hero-visual')
        if (!visual) return
        gsap.to(visual, {
          yPercent: 7,
          ease: 'none',
          scrollTrigger: { trigger: '.landing-hero', start: 'top top', end: 'bottom top', scrub: true },
        })
      })
    })()
    return () => {
      cancelled = true
      context?.revert()
    }
  }, [reduced])

  return (
    <div className={cn('landing-shell', reduced && 'landing-reduced')}>
      <Preloader />
      <SmoothScroll />
      <LandingCursor />
      <div className="landing-grain" aria-hidden="true" />
      <Nav
        theme={theme}
        onToggleTheme={toggleTheme}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
        onOpenCommand={() => {
          setToasterReady(true)
          setCommandOpen(true)
        }}
        play={play}
      />

      <main id="main-content">
        <Hero theme={theme} play={play} />
        <Marquee />
        <Features />
        <StackSection />
        <DataSection />
        <StartSection play={play} />
      </main>

      <Footer />
      {commandOpen ? (
        <CommandMenu
          open
          onOpenChange={setCommandOpen}
          theme={theme}
          onToggleTheme={toggleTheme}
          soundEnabled={soundEnabled}
          onToggleSound={toggleSound}
          play={play}
        />
      ) : null}
      {toasterReady ? (
        <Toaster
          theme={theme}
          position="bottom-left"
          closeButton
          toastOptions={{
            style: {
              background: 'rgba(13, 17, 30, 0.94)',
              border: '1px solid rgba(148, 163, 184, 0.18)',
              color: '#e9edf9',
              fontFamily: 'var(--font)',
              direction: 'rtl',
            },
          }}
        />
      ) : null}
    </div>
  )
}
