'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

const STORAGE_KEY = 'moroor-sound'
const GATE_KEY = 'moroor-sound-gate'

type SoundKind = 'tap' | 'confirm' | 'error'

/**
 * Tiny synthesized feedback, disabled by default. No audio assets are loaded
 * before the first deliberate interaction and no sound plays without opt-in.
 */
export function useSoundDesign() {
  const [enabled, setEnabled] = useState(false)
  const enabledRef = useRef(false)
  const contextRef = useRef<AudioContext | null>(null)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY) === '1'
      enabledRef.current = stored
      setEnabled(stored)
    } catch {
      /* ignore */
    }
  }, [])

  const tone = useCallback((kind: SoundKind) => {
    if (typeof window === 'undefined') return
    const AudioCtor = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AudioCtor) return
    try {
      const context = contextRef.current ?? new AudioCtor()
      contextRef.current = context
      if (context.state === 'suspended') void context.resume()
      const now = context.currentTime
      const oscillator = context.createOscillator()
      const gain = context.createGain()
      const base = kind === 'error' ? 220 : kind === 'confirm' ? 720 : 540
      oscillator.type = 'sine'
      oscillator.frequency.setValueAtTime(base, now)
      oscillator.frequency.exponentialRampToValueAtTime(kind === 'error' ? 160 : base * 1.35, now + 0.075)
      gain.gain.setValueAtTime(0.0001, now)
      gain.gain.exponentialRampToValueAtTime(0.035, now + 0.012)
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11)
      oscillator.connect(gain)
      gain.connect(context.destination)
      oscillator.start(now)
      oscillator.stop(now + 0.12)
    } catch {
      /* audio can be blocked; silence is a valid fallback */
    }
  }, [])

  const play = useCallback((kind: SoundKind = 'tap') => {
    if (!enabledRef.current) return
    tone(kind)
  }, [tone])

  const toggle = useCallback(() => {
    setEnabled(current => {
      const next = !current
      enabledRef.current = next
      try {
        if (next) {
          localStorage.setItem(STORAGE_KEY, '1')
          localStorage.setItem(GATE_KEY, '1')
        } else {
          localStorage.removeItem(STORAGE_KEY)
        }
      } catch {
        /* ignore */
      }
      if (next) tone('confirm')
      return next
    })
  }, [tone])

  return { soundEnabled: enabled, toggleSound: toggle, play }
}

export type SoundDesign = ReturnType<typeof useSoundDesign>
