# گزارش اعتبارسنجی Moroor V2

## اجراشده

| بررسی | دستور | نتیجه |
| --- | --- | --- |
| آزمون منطق داده | `npm test` | ۲۶ موفق، ۰ ناموفق |
| TypeScript | `npm run typecheck` | موفق |
| Build تولیدی | `npm run build` | موفق؛ Next.js 15، خروجی استاتیک `out/` |
| لندینگ در مرورگر | ۱۴۴۰px و ۳۹۰px | بارگذاری شد، سرریز افقی ندارد، title و CTA دیده می‌شوند |
| تم روشن/تیره | کلیک روی toggle | `data-theme` تغییر کرد و در داشبورد نیز حفظ شد |
| Command palette | `Ctrl+K` | باز شد؛ جست‌وجو و مسیرها نمایش داده شدند |
| حالت کاهش حرکت | `prefers-reduced-motion: reduce` | پیش‌بارگذار و WebGL حذف شدند؛ محتوا و CTA بدون انیمیشن دیده شدند |
| ۴۰۴ | `/missing-page/` | صفحهٔ سفارشی با عنوان مستقل |
| داشبورد | `/app/` | در حالت محلی، داشبورد و بنر وضعیت بارگذاری شدند |
| Lighthouse موبایل | خروجی استاتیک `out/` | Performance ۹۴، Accessibility ۱۰۰، Best Practices ۱۰۰، SEO ۱۰۰ |
| Lighthouse دسکتاپ | خروجی استاتیک `out/` | Performance ۹۹، Accessibility ۱۰۰، Best Practices ۱۰۰، SEO ۱۰۰ |

Build نهایی: `Route /` حدود ۸۵٫۶kB و `/app` حدود ۱٫۵kB (بدون chunkهای lazy مانند WebGL، GSAP، command palette و toaster)؛ صفحهٔ لندینگ در مجموع حدود ۱۸۳kB First Load JS دارد. در Lighthouse موبایل: FCP و LCP برابر ۱٫۵s، TBT برابر ۲۷۰ms و CLS برابر ۰؛ در دسکتاپ: LCP ۰٫۴s، TBT ۳۰ms و CLS ۰.

## آزمون‌نشده

- Supabase واقعی: ورود، RLS، Realtime، همگام‌سازی دو دستگاه و اجرای migrationها (بدون پروژه/اعتبارنامه).
- Lighthouse روی شبکهٔ محلی و Chrome headless اجرا شد؛ اعداد بالا از همان اجرا هستند. نمره ممکن است با سخت‌افزار/شبکهٔ واقعی چند امتیاز نوسان کند.
- انتشار واقعی GitHub Pages و مسیر basePath در Actions.
- خواندن/نوشتن فایل واقعی Excel در مرورگر.
- تعامل لمسی و اسکرول روی دستگاه واقعی موبایل؛ بررسی با viewport شبیه‌سازی‌شده انجام شد.

## نکتهٔ موشن

متن فارسی حرف‌به‌حرف split نشده است چون جداسازی حروف، اتصال قلم فارسی را می‌شکند. واژه‌ها با stagger و ماسک reveal می‌شوند؛ این تصمیم عمدی برای حفظ شکل صحیح خط است. انیمیشن‌ها بر پایهٔ transform/opacity هستند و حالت کاهش حرکت آن‌ها را غیرفعال می‌کند.
