'use client'

import { useRouter } from 'next/navigation'
import {
  ArrowUpRight,
  BookOpen,
  CalendarCheck2,
  Copy,
  LayoutDashboard,
  Moon,
  ShieldCheck,
  Sparkles,
  Sun,
  Volume2,
  VolumeX,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from '@/components/ui/command'
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog'
import { copyCurrentLink, scrollToSection } from '@/lib/scroll'
import type { ThemeName } from '@/lib/theme'

type CommandMenuProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  theme: ThemeName
  onToggleTheme: () => void
  soundEnabled: boolean
  onToggleSound: () => void
  play: (kind?: 'tap' | 'confirm' | 'error') => void
}

export function CommandMenu({
  open,
  onOpenChange,
  theme,
  onToggleTheme,
  soundEnabled,
  onToggleSound,
  play,
}: CommandMenuProps) {
  const router = useRouter()

  function run(action: () => void) {
    play('confirm')
    action()
    onOpenChange(false)
  }

  function goToSection(id: string) {
    run(() => scrollToSection(id))
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent hideClose className="overflow-hidden p-0" aria-describedby={undefined}>
        <DialogTitle className="sr-only">دستورها و مسیرهای سریع</DialogTitle>
        <DialogDescription className="sr-only">
          جست‌وجوی بخش‌ها و تنظیمات سایت
        </DialogDescription>
        <Command label="دستورها" dir="rtl" className="bg-transparent">
          <CommandInput placeholder="جست‌وجو در مسیرها و تنظیمات…" autoFocus />
          <CommandList>
            <CommandEmpty>چیزی پیدا نشد.</CommandEmpty>
            <CommandGroup heading="مسیرها">
              <CommandItem onSelect={() => run(() => router.push('/app'))}>
                <LayoutDashboard size={15} aria-hidden="true" />
                ورود به داشبورد
                <CommandShortcut>↗</CommandShortcut>
              </CommandItem>
              <CommandItem onSelect={() => goToSection('features')}>
                <Sparkles size={15} aria-hidden="true" />
                امکانات
              </CommandItem>
              <CommandItem onSelect={() => goToSection('how')}>
                <BookOpen size={15} aria-hidden="true" />
                چطور کار می‌کند
              </CommandItem>
              <CommandItem onSelect={() => goToSection('data')}>
                <ShieldCheck size={15} aria-hidden="true" />
                داده و امنیت
              </CommandItem>
              <CommandItem onSelect={() => goToSection('start')}>
                <CalendarCheck2 size={15} aria-hidden="true" />
                شروع مطالعه
              </CommandItem>
            </CommandGroup>
            <CommandSeparator />
            <CommandGroup heading="تنظیمات">
              <CommandItem onSelect={() => run(onToggleTheme)}>
                {theme === 'dark' ? <Sun size={15} aria-hidden="true" /> : <Moon size={15} aria-hidden="true" />}
                {theme === 'dark' ? 'روشن‌کردن تم' : 'تیره‌کردن تم'}
              </CommandItem>
              <CommandItem onSelect={() => run(onToggleSound)}>
                {soundEnabled ? <VolumeX size={15} aria-hidden="true" /> : <Volume2 size={15} aria-hidden="true" />}
                {soundEnabled ? 'قطع صدا' : 'روشن‌کردن صدا'}
              </CommandItem>
              <CommandItem
                onSelect={() => run(() => {
                  void copyCurrentLink()
                    .then(() => toast.success('لینک صفحه کپی شد.'))
                    .catch(() => toast.error('کپی لینک ممکن نشد.'))
                })}
              >
                <Copy size={15} aria-hidden="true" />
                کپی لینک این صفحه
              </CommandItem>
            </CommandGroup>
            <CommandSeparator />
            <CommandGroup heading="دربارهٔ برنامه">
              <CommandItem
                onSelect={() => run(() => {
                  window.open('https://github.com/ll4mirffx56/Konkur-System', '_blank', 'noopener,noreferrer')
                })}
              >
                <ArrowUpRight size={15} aria-hidden="true" />
                مخزن پروژه در GitHub
                <CommandShortcut>↗</CommandShortcut>
              </CommandItem>
            </CommandGroup>
          </CommandList>
        </Command>
        <div className="flex items-center justify-between gap-3 border-t border-[var(--line)] px-3 py-2 text-[10px] text-[var(--muted)]">
          <span>↵ رفتن</span>
          <span>esc بستن</span>
          <span dir="ltr">⌘K / Ctrl K</span>
        </div>
      </DialogContent>
    </Dialog>
  )
}
