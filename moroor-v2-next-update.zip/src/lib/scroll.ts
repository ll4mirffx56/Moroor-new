import type Lenis from 'lenis'

let instance: Lenis | null = null

export function registerLenis(lenis: Lenis | null): void {
  instance = lenis
}

/** Scrolls to a landing section without fighting Lenis or reduced-motion users. */
export function scrollToSection(id: string): void {
  if (typeof window === 'undefined') return
  const target = document.getElementById(id)
  if (!target) return
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  if (instance && !reduced) {
    instance.scrollTo(target, { offset: -76, duration: 1.15 })
    return
  }
  target.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' })
}

export function copyCurrentLink(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve()
  return navigator.clipboard.writeText(window.location.href)
}
