import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const badgeVariants = cva(
  'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium leading-none',
  {
    variants: {
      variant: {
        default: 'border-[var(--line)] bg-[var(--surface-2)] text-[var(--text-soft)]',
        accent: 'border-[rgba(109,140,255,0.28)] bg-[var(--accent-soft)] text-[var(--accent-strong)]',
        positive: 'border-[rgba(61,220,151,0.24)] bg-[rgba(61,220,151,0.1)] text-[var(--positive)]',
      },
    },
    defaultVariants: { variant: 'default' },
  },
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />
}

export { Badge, badgeVariants }
