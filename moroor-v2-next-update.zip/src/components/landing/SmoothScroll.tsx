'use client'

import { useEffect } from 'react'
import type Lenis from 'lenis'
import { useReducedMotion } from 'framer-motion'
import { registerLenis } from '@/lib/scroll'
import { usePointerFine } from '@/lib/theme'

/** Smooth wheel scrolling on precise pointers only; native on touch/reduced motion. */
export function SmoothScroll() {
  const reduced = useReducedMotion()
  const fine = usePointerFine()

  useEffect(() => {
    if (reduced || !fine) {
      registerLenis(null)
      return
    }
    let lenis: Lenis | null = null
    let frame = 0
    let cancelled = false

    void import('lenis').then(({ default: Lenis }) => {
      if (cancelled) return
      lenis = new Lenis({
        duration: 1.05,
        smoothWheel: true,
        wheelMultiplier: 0.9,
        touchMultiplier: 0,
        syncTouch: false,
      })
      registerLenis(lenis)
      const raf = (time: number) => {
        lenis?.raf(time)
        frame = requestAnimationFrame(raf)
      }
      frame = requestAnimationFrame(raf)
    })

    return () => {
      cancelled = true
      cancelAnimationFrame(frame)
      lenis?.destroy()
      registerLenis(null)
    }
  }, [fine, reduced])

  return null
}
