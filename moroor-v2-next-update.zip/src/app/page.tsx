import type { Metadata } from 'next'
import { LandingPage } from '@/components/landing/LandingPage'

export const metadata: Metadata = {
  title: 'مرور | سیستم مدیریت مطالعه و مرور',
  description: 'برنامه‌ریزی مطالعه، مرور فاصله‌دار، آزمون با نمرهٔ منفی، دوره و گزارش واقعی با تقویم شمسی.',
}

export default function HomePage() {
  return <LandingPage />
}
