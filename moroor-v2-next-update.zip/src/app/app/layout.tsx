import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'داشبورد',
  description: 'داشبورد مطالعهٔ مرور: برنامه، آزمون، دوره و گزارش.',
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return children
}
